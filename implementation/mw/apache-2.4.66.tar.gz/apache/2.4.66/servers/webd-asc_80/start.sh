#!/bin/sh

. ./env.sh

SETUSER="midadm"
RUNNER=`whoami`

if [ ${RUNNER} != ${SETUSER} ] ; then 
   echo "Den Access : [ ${RUNNER} ]. Not ${SETUSER}" ;
   exit 0 ;
fi

# start shell
${ENGN_HOME}/bin/apachectl -f ${INSTALL_PATH}/conf/httpd.conf -k start
