#!/bin/bash

export ENGN_HOME=/engn001/apache/2.4.66
export SERVICE_PORT=80
export HTTPS_SERVICE_PORT=443
export SYSTEM=asc
export SERVER_ID=webd-${SYSTEM}_${SERVICE_PORT}
export INSTALL_PATH=${ENGN_HOME}/servers/${SERVER_ID}
export DOC_ROOT=/sorc001/appadm/applications/htdocs
